<div>
    <h1> Hello {{ $user->name }}</h1>
    <p>Thank you for signing up to task management system api</p>
</div>

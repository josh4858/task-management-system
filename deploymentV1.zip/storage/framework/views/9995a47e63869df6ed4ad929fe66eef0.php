<div>
    <h1> Hello <?php echo e($user->name); ?></h1>
    <p>Thank you for signing up to task management system api</p>
</div>
<?php /**PATH C:\Users\robjo\Documents\LaravelProjects\task_management_api\resources\views/emails/welcome.blade.php ENDPATH**/ ?>